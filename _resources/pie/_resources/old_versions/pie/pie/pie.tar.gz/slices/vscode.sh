#!/bin/bash

#  PROJECT: pie
# FILENAME: vscode.sh
#    BUILD: 170316
#
# Copyright 2017 A Pretty Cool Program
#
# pie is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
# compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
# an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under the License.
#
# For more information about pie, please visit http://aprettycoolprogram.com/pie.

# Visual Studio Code.
# https://code.visualstudio.com/docs/setup/linux

source "$pieFolder/slices/piengine.sh"

# Install VSCode
function Install()
{ 
    # Set logfile.
    SetLogfileName "$scriptName" "${FUNCNAME[0],,}" "$@"

    case $1 in
        "help")
            helpContent="
%2s      <none> %2sInstalls Visual Studio Code from aprettycoolprogram.com
%2s      source %2sInstalls Visual Studio Code from Microsoft"      
            DisplayHelp "${0#*./}" "install" "$helpContent"
            ExitPie ""
            ;;
        "")
            StartActionMsg $scriptName ${FUNCNAME[0],,} $@
        printf "%2sDownloading Visual Studio Code installer..."
        curl -k https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg  > "$logfile" 2>&1
	    sudo mv microsoft.gpg /etc/apt/trusted.gpg.d/microsoft.gpg >> "$logfile" 2>&1
	    sudo sh -c 'echo "deb [arch=amd64] http://packages.microsoft.com/repos/vscode stable main" > /etc/apt/sources.list.d/vscode.list' >> "$logfile" 2>&1
	    sudo apt-get update >> "$logfile" 2>&1
	    sudo apt-get install code  >> "$logfile" 2>&1
	    #sudo dpkg -i code*.deb
	    #sudo apt-get install -f 
	    printf "${fG}complete!${tR}"
            CompleteActionMsg
            ;;
        *)
            if (( "$#" > 0 )); then
            ExitPie "Invalid command, exiting."
            fi   
            ;;
    esac
}

## Creates desktop icon.
function Icon()
{
    case $1 in
        "help")
            helpContent="
%2s      <none> %2sCreates a desktop icon for Visual Studio Code
%2s       nogpu %2sCreates a desktop icon for Visual Studio Code that disables the GPU"      
            DisplayHelp "${0#*./}" "icon" "$helpContent"
            ExitPie ""
            ;;
        "")
            appArguments=""
            ;;
        "nogpu")
            appArguments="--disable-gpu"
            ;;     
        *)
            if (( "$#" > 0 )); then
            ExitPie "%2sInvalid command, exiting."
            fi   
            ;;
    esac
    
    StartActionMsg $scriptName ${FUNCNAME[0],,} $@
    printf "%2sCreating desktop icon for Visual Studio Code..."
    DesktopIcon "UTF-8" "1.0" "VS-CODE" "VS-CODE" "/usr/bin/code $appArguments" "false" "/opt/yed-3.11.1/icons/yicon32.png" "Application" "Application;Programming;" "Visual Studio Code"
    printf "$desktopIcon" > $HOME/Desktop/vscode.desktop
    chmod +x $HOME/Desktop/vscode.desktop
    printf "${fG}complete!${tR}"
    CompleteActionMsg
	
}

# Help screen.
function Help() 
{
    DisplayHelp "${0#*./}" "actions" "$validActions"
    ExitPie "Have a nice day!"
}

# Get the valid actions for this script, then get the base script name, since it's used in log files and
# the else statement.
GetFunctionNamesFor "validActions" "${0#*./}"
scriptName="$(basename ${0#*./})"
scriptName="${scriptName%.*}"

# If arguments are passed, check to see if the first is an action. If it is, call the action. If it's not an action,
# display a help message. If no arguments were passed, display the menu.
if (( "$#" > 0 )); then
    if [[ ${validActions[*]} =~ "$1" ]]; then  	
        declare -c action="$1"
	    eval "$action ${@:2}"
    else
        ExitPie "Invalid action. Please type \"pie $scriptName help\" for more information."	
    fi
else
    Help
fi